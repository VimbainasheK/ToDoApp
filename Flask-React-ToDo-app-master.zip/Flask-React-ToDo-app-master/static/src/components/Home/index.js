import React from 'react';

export const Home = () =>
    <section>
        <div className="container text-center">
            <h1>UCLA Extension 2017</h1>
            <h2>Time Managment Assistant</h2>
        </div>
    </section>;
