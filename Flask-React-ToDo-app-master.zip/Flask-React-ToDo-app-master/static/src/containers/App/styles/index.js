import 'style!./styles.scss';
export default require('./styles.scss').locals.styles;
